package com.example.birdview

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.birdview.databinding.ActivityFullMapBinding
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.LatLng
import com.mapbox.geojson.Point

import com.mapbox.maps.MapView
import com.mapbox.maps.MapboxMap
import com.mapbox.maps.plugin.Plugin

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray

class FullMap : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var binding: ActivityFullMapBinding
    private lateinit var mapView: MapView
    private lateinit var mapboxMap: MapboxMap

    private val yourLatitude = 40.7128
    private val yourLongitude = -74.0060

    private val eBirdApiKey = "9riis08rlgc2"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Mapbox.getInstance(this, "YOUR_MAPBOX_ACCESS_TOKEN")
        binding = ActivityFullMapBinding.inflate(layoutInflater)
        setContentView(binding.root)
        mapView = binding.mapView
        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync(this)
    }

    override fun onMapReady(mapboxMap: MapboxMap) {
        this.mapboxMap = mapboxMap

        // Add a symbol for your location
        val yourLocation = LatLng(yourLatitude, yourLongitude)
        addMarker(yourLocation, "Your Location")

        // Fetch bird observations and display markers
        fetchBirdObservations()
    }

    private fun addMarker(location: LatLng, title: String) {
        val symbolOptions = SymbolOptions()
            .withLatLng(location)
            .withIconImage("marker-icon")
            .withIconSize(2.0f)
            .withTextField(title)
            .withTextOffset(arrayOf(0f, 1.5f))

        mapboxMap.style?.addImage("marker-icon", yourMarkerBitmap)

        val symbol = mapboxMap.addSymbol(symbolOptions)
    }



    private fun fetchBirdObservations() {
        GlobalScope.launch(Dispatchers.IO) {
            try {
                val client = OkHttpClient()
                val request = Request.Builder()
                    .url("https://api.ebird.org/v2/data/obs/geo/recent?lat=$yourLatitude&lng=$yourLongitude")
                    .header("X-eBirdApiToken", eBirdApiKey)
                    .build()

                val response = client.newCall(request).execute()
                if (response.isSuccessful) {
                    val jsonString = response.body?.string()
                    val birdObservations = parseBirdObservations(jsonString)
                    displayBirdMarkers(birdObservations)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun parseBirdObservations(jsonString: String?): List<Point> {
        val birdObservations = mutableListOf<Point>()
        jsonString?.let {
            val jsonArray = JSONArray(it)
            for (i in 0 until jsonArray.length()) {
                val observation = jsonArray.getJSONObject(i)
                val lat = observation.getDouble("lat")
                val lon = observation.getDouble("lng")
                birdObservations.add(Point.fromLngLat(lon, lat))
            }
        }
        return birdObservations
    }

    private fun displayBirdMarkers(birdObservations: List<Point>) {
        for (observation in birdObservations) {
            addMarker(LatLng(observation.latitude(), observation.longitude()), "Bird Observation")
        }
    }

    override fun onStart() {
        super.onStart()
        mapView.onStart()
    }



    override fun onDestroy() {
        super.onDestroy()
        mapView.onDestroy()
    }
}
